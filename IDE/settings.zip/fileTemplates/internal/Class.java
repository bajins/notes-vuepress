#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end


import org.slf4j.Logger;

#parse("File Header.java")

public class ${NAME} {

     private static final Logger logger = org.slf4j.LoggerFactory.getLogger(${NAME}.class);
     
     
}