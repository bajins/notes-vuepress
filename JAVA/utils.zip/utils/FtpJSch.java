package com.cyw.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.cyw.bill.model.SFile;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;  

public class FtpJSch {
	
	
	private static ChannelSftp sftp = null;  
    
    //账号  
    private static String user = "root";  
    //主机ip  
    private static String host =  "120.76.101.100";  
    //密码  
    private static String password = "Jktz2017!@#";  
    //端口  
    private static int port = 22;  
    //上传地址  
    private static String directory = "/ftp";  
    //合同模板文件上传地址
    private static String contract = "/systemcontract";
    //下载目录  
    private static String saveFile = "D:\\";  
      
    public static FtpJSch getConnect(){  
        FtpJSch ftp = new FtpJSch();  
        try {  
            JSch jsch = new JSch();  
  
            //获取sshSession  账号-ip-端口  
            Session sshSession =jsch.getSession(user, host,port);  
            //添加密码  
            sshSession.setPassword(password);  
            Properties sshConfig = new Properties();  
            //严格主机密钥检查  
            sshConfig.put("StrictHostKeyChecking", "no");  
              
            sshSession.setConfig(sshConfig);  
            //开启sshSession链接  
            sshSession.connect();  
            //获取sftp通道  
            Channel channel = sshSession.openChannel("sftp");  
            //开启  
            channel.connect();  
            sftp = (ChannelSftp) channel;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return ftp;  
    }  
      
    /** 
     *  
     * @param uploadFile 上传文件的路径 
     * @return 服务器上文件名 
     */  
    /*public String upload(InputStream inputStream,String fileName) {  
       
    	
    	File file = null;  
   //     String fileName = null;  
        try {  
        	getConnect();
            sftp.cd(directory);  
      //      file = new File(uploadFile);  
            //获取随机文件名  
     //       fileName  = UUID.randomUUID().toString() + file.getName().substring(file.getName().length()-5);  
            //文件名是 随机数加文件名的后5位  
            sftp.put(inputStream, fileName);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return file == null ? null : fileName;  
    }  */
    
    /**
     * 上传文件
     * @param pathname ftp服务保存地址
     * @param fileName 上传到ftp的文件名
     * @param inputStream 输入文件流 
     * @return
     */
    public boolean upload(String pathname, String fileName,InputStream inputStream) throws IOException {  
       
    	boolean flag = false;
        try{
            System.out.println("开始上传文件");
            getConnect();
            sftp.cd(directory);  
         // 判断子目录文件夹是否存在，不存在即创建  
            SftpATTRS attrs = null;  
            try {  
                attrs = sftp.stat(pathname);  
            } catch (Exception e) {  
                // TODO: handle exception  
            }  
            if (attrs == null) {  
                sftp.mkdir(pathname);  
            }
            sftp.cd(pathname);
            sftp.put(inputStream, fileName);
            flag = true;
            System.out.println("上传文件成功");
        }catch (Exception e) {
            System.out.println("上传文件失败");
            e.printStackTrace();
        }finally{
            if(sftp.isConnected()){ 
                sftp.disconnect();
            } 
            if(null != inputStream){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } 
            } 
        }
        return flag;
    }  
    
    /**
     * 系统合同模板上传
     * @param pathname
     * @param fileName
     * @param inputStream
     * @return
     * @throws IOException
     */
    /*public boolean upload(String pathname,String subclass_name, String fileName,InputStream inputStream) throws IOException {  
        
    	boolean flag = false;
        try{
            System.out.println("开始上传文件");
            getConnect();
            sftp.cd(contract);  
         // 判断子目录文件夹是否存在，不存在即创建  
            SftpATTRS attrs = null;  
            try {  
                attrs = sftp.stat(pathname);  
            } catch (Exception e) {  
                // TODO: handle exception  
            }  
            if (attrs == null) {  
                sftp.mkdir(pathname);  
            }
            sftp.cd(pathname);
            
            if(StringUtils.isNotEmpty(subclass_name)){
            	 attrs = null;
                 try {  
                     attrs = sftp.stat(subclass_name);  
                 } catch (Exception e) {  
                     // TODO: handle exception  
                 }  
                 if (attrs == null) {  
                     sftp.mkdir(subclass_name);  
                 }
                 sftp.cd(subclass_name);
            }
           
            sftp.put(inputStream, fileName);
            flag = true;
            System.out.println("上传文件成功");
        }catch (Exception e) {
            System.out.println("上传文件失败");
            e.printStackTrace();
        }finally{
            if(sftp.isConnected()){ 
                sftp.disconnect();
            } 
            if(null != inputStream){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } 
            } 
        }
        return flag;
    }  */
  
    
    
      
    /** 
     * 下载报单附件图片文件 
     * 用于预览
     * @param directory 
     *            下载目录 
     * @param downloadFile 
     *            下载的文件名 
     * @param saveFile 
     *            存在本地的路径 
     * @param sftp 
     */  
   /* public void download(String downloadFileName,String all_id) {  
        try {  
        	getConnect();
            sftp.cd(directory+"/"+all_id);
            String path = System.getProperty("evan.webapp")+"upload"+ File.separator +all_id+File.separator;
            File file = new File(path); 
            if(!file .exists()  && !file .isDirectory())      
        	{       
        	    System.out.println("//不存在");  
        	    file.mkdirs();
        	}
            File file1 = new File(path+downloadFileName); 
            judeFileExists(file1);
            File file3 = new File(path+File.separator+downloadFileName); 
            sftp.get(downloadFileName, new FileOutputStream(file3));  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  finally{
            if(sftp.isConnected()){ 
                sftp.disconnect();
            } 
        }
    }  */
    
 // 判断文件是否存在
    /*public static void judeFileExists(File file) {
        if (file.exists()) {
        	file.delete();       
        } else {
            System.out.println("file not exists, create it ...");
        }

    }
      
    // 判断文件夹是否存在
    public static void judeDirExists(File file) {

    	if  (!file .exists()  && !file .isDirectory())      
    	{       
    	    System.out.println("//不存在");  
    	    file.mkdirs();    
    	} else   
    	{  
    	    System.out.println("//目录存在");  
    	}  

    }*/

    
    
    /** 
     * 删除文件 
     *  
     * @param deleteFile 
     *            要删除的文件名字 
     * @param sftp 
     */  
   /* public void delete(String deleteFile) {  
        try {  
            sftp.cd(directory);  
            sftp.rm(deleteFile);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  */
      
    /** 
     * 列出目录下的文件 
     *  
     * @param directory 
     *            要列出的目录 
     * @param sftp 
     * @return 
     * @throws SftpException 
     */  
    /*public Vector listFiles(String directory)  
            throws SftpException {  
        return sftp.ls(directory);  
    }  */
	
    /**
     * 下载文件  
     * @param directory 下载目录  
     * @param downloadFile 下载的文件名  
     * @param folderName 文件夹名称 
     * 图片 upload 合同contract
     * @return 字节数组
     */
   /* @SuppressWarnings("finally")
	public String downloadByte(String directory, String downloadFileName,String folderName,String billid) throws SftpException, IOException{
        if (directory != null && !"".equals(directory)) {
        	getConnect();
        	sftp.cd(directory);
        }
        String path = System.getProperty("evan.webapp")+folderName+ File.separator;
        if(StringUtils.isNotEmpty(billid)){
        	path = System.getProperty("evan.webapp")+folderName+ File.separator+billid+File.separator;
        }
        String filePath ="";
        try{
        	File file = new File(path); 
            if(!file .exists()  && !file .isDirectory())      
        	{       
        	    file.mkdirs();
        	}
            File file1 = new File(path+downloadFileName); 
            judeFileExists(file1);
            File file3 = new File(path+File.separator+downloadFileName); 
            sftp.get(downloadFileName, new FileOutputStream(file3)); 
            System.out.println(file3.getPath());
            filePath = file3.getPath();
        }catch(Exception e){
        	
        }finally{
            if(sftp.isConnected()){ 
                sftp.disconnect();
            } 
         return filePath;
     }
    }
    
    *//**
     * 循环下载用户的文件
     * @param list
     * @throws IOException 
     * @throws SftpException 
     *//*
    public void imagedisplay(List<SFile> list) throws SftpException, IOException{
		if(list!=null && list.size()>0){
			for(SFile sf:list ){
				String path = StringUtils.substringBeforeLast(sf.getFile_path(), File.separator);
				path = path.replace(File.separator, "/");
				this.downloadByte(path.trim(), sf.getFile_name().trim(), "upload",sf.getAll_id().toString());
			}
		}
	}
    */
    
    

}
