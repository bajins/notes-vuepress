package com.cyw.api.utils;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.comparators.ComparableComparator;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author claer
 * @program com.cyw.api.utils
 * @description SortingUtil 排序类
 * @create 2018-05-19 19:00
 */
public class SortingUtil {

    /**
     * @param list      待排序的集合
     * @param fieldName 依据这个字段进行排序
     * @param asc       如果为true，是正序；为false，为倒序
     * @return void
     * @Description TODO sort 对List集合中的泛型中的bean某一个字段排序
     * @author claer claer@ichangg.com
     * @date 2018-05-18 17:26
     */
    public static <T> void sort(List<T> list, String fieldName, boolean asc) {
        Comparator<?> mycmp = ComparableComparator.getInstance();
        mycmp = ComparatorUtils.nullLowComparator(mycmp); // 允许null
        if (!asc) {
            mycmp = ComparatorUtils.reversedComparator(mycmp); // 逆序
        }
        Collections.sort(list, new BeanComparator(fieldName, mycmp));
    }
}
