package com.cyw.api.log.service;

import com.cyw.api.log.model.SystemLog;

public interface SystemLogService {

	int save(SystemLog systemLogModel);
}
