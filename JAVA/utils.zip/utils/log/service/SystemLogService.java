package com.cyw.log.service;

import com.cyw.log.model.SystemLogModel;

public interface SystemLogService {

	int save(SystemLogModel systemLogModel);
}
