package com.cyw.log.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cyw.log.dao.SystemLogMapper;
import com.cyw.log.model.SystemLogModel;
import com.cyw.log.service.SystemLogService;

@Service
public class SystemLogServiceImpl implements SystemLogService{

	@Resource
	private SystemLogMapper systemLogMapper;
	
	
	@Override
	public int save(SystemLogModel systemLogModel) {
		// TODO Auto-generated method stub
		return systemLogMapper.save(systemLogModel);
	}

	
}
