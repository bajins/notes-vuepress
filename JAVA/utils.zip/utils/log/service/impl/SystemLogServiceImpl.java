package com.cyw.api.log.service.impl;

import javax.annotation.Resource;

import com.cyw.api.log.dao.SystemLogMapper;
import com.cyw.api.log.model.SystemLog;
import org.springframework.stereotype.Service;

import com.cyw.api.log.service.SystemLogService;

@Service
public class SystemLogServiceImpl implements SystemLogService{

	@Resource
	private SystemLogMapper systemLogMapper;
	
	
	@Override
	public int save(SystemLog systemLogModel) {
		// TODO Auto-generated method stub
		return systemLogMapper.insertSelective(systemLogModel);
	}

	
}
