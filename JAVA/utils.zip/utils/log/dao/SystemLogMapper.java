package com.cyw.log.dao;


import com.cyw.log.model.SystemLogModel;

public interface SystemLogMapper {

	int save(SystemLogModel systemLogModel);
}
