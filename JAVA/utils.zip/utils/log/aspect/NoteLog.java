package com.cyw.api.log.aspect;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.cyw.api.log.model.SystemLog;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cyw.api.utils.DateTimeUtil;
import com.cyw.api.log.annotation.EnableLog;
import com.cyw.api.log.service.SystemLogService;

/**
 * 需要包aspectjrt-1.8.13.jar
 * 需要包aspectjweaver-1.8.13.jar
 * @program com.cyw.api.utils.log.annotation
 * @description 开启AOP日志
 * @author claer zd966@zd966.com
 * @create 2018.5.4
 * 使用方法@EnableLog(description="自定义描述")
 */
@Aspect
@Component
public class NoteLog {

	// 注入Service用于把日志保存数据库
	@Resource
	private SystemLogService systemLogService;

	// 本地异常日志记录对象
	private static final Logger logger = LoggerFactory.getLogger(NoteLog.class);

	// 切入点
	@Pointcut("@annotation(com.cyw.api.log.annotation.EnableLog)")
	public void Aspect() {
		logger.info("========Aspect===========");
	}

	/**
	 * 前置通知 用于拦截操作
	 * 
	 * @param joinPoint
	 *            切点
	 */
	@Before("Aspect()")
	public void doBefore(JoinPoint joinPoint) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		// 获取登陆用户信息
		// Manager manager = (Manager)request.getSession().getAttribute("user");
		// 获取用户请求方法的参数并序列化为字符串
		String params = "";
		Object[] args = joinPoint.getArgs();
		if (args != null) {
			// params = StringUtils.join(args, ",");
			params = Arrays.toString(args);
		}
		try {
			// *========控制台输出=========*//
			logger.info("=====前置通知开始=====");
			logger.info("请求方法:"
					+ (joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName() + "()"));
			logger.info("方法描述:" + getMthodDescription(joinPoint));
			// logger.info("请求人:" + manager.getUserName());
			logger.info("请求IP:" + getIpAdrress(request));
			// *========数据库日志=========*//
			SystemLog log = new SystemLog();
			log.setDescription(getMthodDescription(joinPoint));
			log.setMethod(
					(joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName() + "()"));
			log.setType(0);
			log.setIp(getIpAdrress(request));
			log.setAberrantCode(null);
			log.setAberrantDetail(null);
			log.setParams(params);
			// log.setCreateUser(manager.getUserName());
			log.setCreateDate(DateTimeUtil.getDateFormat(new Date()));
			// 保存数据库
			//systemLogService.save(log);
			logger.info("=====前置通知结束=====");
		} catch (Exception e) {
			// 记录本地异常日志
			logger.error("==前置通知异常==");
			logger.error("异常信息:{}", e);
		}
	}

	/**
	 * 异常通知 用于拦截记录异常日志
	 * 
	 * @param joinPoint
	 * @param e
	 */
	@AfterThrowing(pointcut = "Aspect()", throwing = "e")
	public void doAfterThrowing(JoinPoint joinPoint, Throwable e) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		// 获取登陆用户信息
		// Manager manager = (Manager)request.getSession().getAttribute("user");
		// 获取用户请求方法的参数并序列化为字符串
		String params = "";
		Object[] args = joinPoint.getArgs();
		if (args != null) {
			// params = StringUtils.join(args, ",");
			params = Arrays.toString(args);
		}
		try {
			/* ========控制台输出========= */
			logger.info("=====异常通知开始=====");
			logger.info("异常代码:" + e.getClass().getName());
			logger.info("异常信息:" + e.getMessage());
			logger.info("异常方法:"
					+ (joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName() + "()"));
			logger.info("方法描述:" + getMthodDescription(joinPoint));
			// logger.info("请求人:" + manager.getUserName());
			logger.info("请求IP:" + getIpAdrress(request));
			logger.info("请求参数:" + params);
			/* ==========数据库日志========= */
			SystemLog log = new SystemLog();
			log.setDescription(getMthodDescription(joinPoint));
			log.setAberrantCode(e.getClass().getName());
			log.setType(1);
			log.setAberrantDetail(e.getMessage());
			log.setMethod(
					(joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName() + "()"));
			log.setParams(params);
			// log.setCreateUser(manager.getUserName());
			log.setCreateDate(DateTimeUtil.getDateFormat(new Date()));
			log.setIp(getIpAdrress(request));
			// 保存数据库
			//systemLogService.save(log);
			logger.info("=====异常通知结束=====");
		} catch (Exception ex) {
			// 记录本地异常日志
			logger.error("==异常通知异常==");
			logger.error("异常信息:{}", ex);
		}

	}

	/**
	 * 获取注解中对方法的描述信息
	 * 
	 * @param joinPoint
	 *            切点
	 * @return 方法描述
	 * @throws Exception
	 */
	public static String getMthodDescription(JoinPoint joinPoint) throws Exception {
		// 获取目标类名
		String targetName = joinPoint.getTarget().getClass().getName();
		// 获取方法名
		String methodName = joinPoint.getSignature().getName();
		// 获取相关参数
		Object[] arguments = joinPoint.getArgs();
		// 使用反射生成类对象
		Class targetClass = Class.forName(targetName);
		// 获取该类中的方法
		Method[] methods = targetClass.getMethods();

		String description = "";

		for (Method method : methods) {
			// 判断使用反射生成类对象中的方法与使用注解切点进入的方法是否一致
			if (!method.getName().equals(methodName)) {
				continue;
			}
			// 获取使用反射生成类对象中的所有参数类型
			Class[] clazzs = method.getParameterTypes();
			// 参数类型进行判断是否一致
			if (clazzs.length != arguments.length) {
				continue;
			}
			// 获取使用反射生成类对象中使用自定义注解方法上的描述
			description = method.getAnnotation(EnableLog.class).description();
		}
		return description;
	}

	/**
	 * 获取用户真实IP地址，不使用request.getRemoteAddr();的原因是有可能用户使用了代理软件方式避免真实IP地址,
	 * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值，究竟哪个才是真正的用户端的真实IP呢？
	 * 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串。
	 * 
	 * 如：X-Forwarded-For：192.168.1.110, 192.168.1.120, 192.168.1.130,
	 * 192.168.1.100
	 * 
	 * 用户真实IP为： 192.168.1.110
	 * 
	 * @param request
	 * @return
	 */
	private static String getIpAdrress(HttpServletRequest request) {
		String Xip = request.getHeader("X-Real-IP");
		String XFor = request.getHeader("X-Forwarded-For");
		if (StringUtils.isNotEmpty(XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
			// 多次反向代理后会有多个ip值，第一个ip才是真实ip
			int index = XFor.indexOf(",");
			if (index != -1) {
				return XFor.substring(0, index);
			} else {
				return XFor;
			}
		}
		XFor = Xip;
		if (StringUtils.isNotEmpty(XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
			return XFor;
		}
		if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
			XFor = request.getHeader("Proxy-Client-IP");
		}
		if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
			XFor = request.getHeader("WL-Proxy-Client-IP");
		}
		if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
			XFor = request.getHeader("HTTP_CLIENT_IP");
		}
		if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
			XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
			XFor = request.getRemoteAddr();
		}
		return XFor.equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : XFor;
	}

}
