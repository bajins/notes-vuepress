package com.zd966.file.cloud.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author claer
 * @program com.zd966.file.cloud.aspect
 * @description AutomaticLog 拦截请求记录日志类
 * @create 2018-04-24 18:00
 */
@Aspect
@Component
public class AutomaticLog {

    public static final Logger logger = LoggerFactory.getLogger(AutomaticLog.class);

    /**
     * @param
     * @return void
     * @Description TODO log Pointcut 切入点，使用该注解后方便其他注解直接引用,(..)表示这个方法内任何参数都会被拦截
     * @author claer
     * @date 2018/4/24/024 18:17
     */
    @Pointcut("execution(public * com.zd966.file.cloud.controller.LoginController.*(..))")
    public void log() {

    }


    /**
     * @param joinPoint getSignature().getDeclaringTypeName()获取类名
     * @param joinPoint getSignature().getName()获取方法名
     * @param joinPoint getArgs()获取请求参数
     * @return void
     * @Description TODO doBefore Before在请求到方法之前记录，引用注解Pointcut下的log()方法
     * @author claer
     * @date 2018/4/24/024 18:04
     */
    @Before("log()")
    public void doBefore(JoinPoint joinPoint) {

        //HttpServletRequest中拿到request
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest();

        logger.info("请求路径={}", request.getRequestURL());

        logger.info("请求方式={}", request.getMethod());

        logger.info("客户端IP={}", getIpAdrress(request));

        logger.info("类方法={}", joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature()
                .getName());

        logger.info("参数={}", joinPoint.getArgs());
    }

    /**
     * @param joinPoint
     * @return void
     * @Description TODO doAfter After在请求到方法之后记录，引用注解Pointcut下的log()方法
     * @author claer
     * @date 2018/4/24/024 18:14
     */
    @After("log()")
    public void doAfter(JoinPoint joinPoint) {

    }


    /**
     * @param object
     * @return void
     * @Description TODO doAfterReturning AfterReturning获取返回数据，引用注解Pointcut下的log()方法
     * @author claer
     * @date 2018/4/24/024 18:56
     */
    @AfterReturning(returning = "object", pointcut = "log()")
    public void doAfterReturning(Object object) {
        logger.info("返回数据={}", object.toString());
    }

    
    /** 
     * 获取用户真实IP地址，不使用request.getRemoteAddr();的原因是有可能用户使用了代理软件方式避免真实IP地址, 
     * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值，究竟哪个才是真正的用户端的真实IP呢？ 
     * 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串。 
     *  
     * 如：X-Forwarded-For：192.168.1.110, 192.168.1.120, 192.168.1.130, 
     * 192.168.1.100 
     *  
     * 用户真实IP为： 192.168.1.110 
     *  
     * @param request 
     * @return 
     */  
	private static String getIpAdrress(HttpServletRequest request) {
        String Xip = request.getHeader("X-Real-IP");
        String XFor = request.getHeader("X-Forwarded-For");
        if(StringUtils.isNotEmpty(XFor) && !"unKnown".equalsIgnoreCase(XFor)){
            //多次反向代理后会有多个ip值，第一个ip才是真实ip
            int index = XFor.indexOf(",");
            if(index != -1){
                return XFor.substring(0,index);
            }else{
                return XFor;
            }
        }
        XFor = Xip;
        if(StringUtils.isNotEmpty(XFor) && !"unKnown".equalsIgnoreCase(XFor)){
            return XFor;
        }
        if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_CLIENT_IP");
        }
        if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getRemoteAddr();
        }
        return XFor.equals("0:0:0:0:0:0:0:1")?"127.0.0.1":XFor;
    }
}
