package com.zd966.file.cloud.utils;


/**
 * @author claer
 * @program com.zd966.file.cloud.utils
 * @description Result
 * @create 2018-04-24 20:12
 */

public class Result<T> {

    /** 返回状态码. */
    private Integer code;
    /** 返回状态信息. */
    private String message;
    /** 返回数据. */
    private T date;

    public Result() {
    }

    public Result(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getDate() {
        return date;
    }

    public void setDate(T date) {
        this.date = date;
    }

    /**
     * @param object
     * @return com.zd966.file.cloud.utils.Result
     * @Description TODO success 返回成功包含返回数据 
     * @author claer
     * @date 2018/4/24/024 20:27
     */
    public static Result success(Object object){
        Result result=new Result();
        result.setCode(0);
        result.setMessage("成功");
        result.setDate(object);
        return result;
    }

    /**
     * @param 
     * @return com.zd966.file.cloud.utils.Result
     * @Description TODO success 返回成功不包含返回数据 
     * @author claer
     * @date 2018/4/24/024 20:28
     */
    public static Result success(){

        return success(null);
    }

    /**
     * @param code状态码
	 * @param msg状态信息
     * @return com.zd966.file.cloud.utils.Result
     * @Description TODO error 返回错误 
     * @author claer
     * @date 2018/4/24/024 20:28
     */
    public static Result error(Integer code,String msg){
        Result result=new Result();
        result.setCode(code);
        result.setMessage(msg);
        return result;
    }
}
