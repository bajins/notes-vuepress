package com.cyw.util;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 需要包joda-time-2.9.9.jar
 * @program: com.zd966.file.cloud.utils
 * @description: DataTimeUtil
 * @author:
 * @create: 2018-04-13 17:34
 */
public class DateTimeUtil {
	private static Date DAY = new Date();
	
	private static final SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

    /**
     * @param date String类型时间
     * @return java.lang.String
     * @Description TODO getDateFormat 传入String类型时间格式化
     * @author Administrator
     * @date 2018/4/13/013 19:32
     */
    public static String getDateFormat(String date) {
        String trim = date.trim();
        
        String format;
        if (!date.equals("") && date != null) {
            format = DF.format(trim);//格式化日期
        } else {
            
            format = DF.format(DAY);//格式化日期
        }
        return format;
    }

    /**
     * @param date 类型时间
     * @return java.lang.String
     * @Description TODO getDateFormat 传入Date类型时间格式化
     * @author Administrator
     * @date 2018/4/13/013 19:32
     */
    public static String getDateFormat(Date date) {
        
        String format;
        if (!date.equals("") && date != null) {
            format = DF.format(date);//格式化日期
        } else {
            
            format = DF.format(DAY);//格式化日期
        }
        return format;
    }

    /**
     * @param date Long类型时间
     * @return java.lang.String
     * @Description TODO getDateFormat  传入Long类型时间格式化
     * @author Administrator
     * @date 2018/4/13/013 19:31
     */
    public static String getDateFormat(Long date) {
        
        String format;
        if (!date.equals("") && date != null) {
            format = DF.format(date);//格式化日期
        } else {
            format = DF.format(DAY);//格式化日期
        }
        return format;
    }

    /**
     * @param date string类型的时间
     * @param specification 格式
     * @return java.lang.String
     * @Description TODO getDateFormat 传入string类型时间和格式进行格式化
     * @author Administrator
     * @date 2018/4/13/013 19:31
     */
    public static String getDateFormat(String date, String specification) {
        if (specification.equals("")) {
            return null;
        }
        String sTrim = specification.trim();
        String trim = date.trim();
        SimpleDateFormat df = new SimpleDateFormat(sTrim);//设置日期格式
        String format;
        if (!date.equals("") && date != null) {
            format = df.format(trim);//格式化日期
        } else {
            
            format = df.format(DAY);//格式化日期
        }
        return format;
    }


    /**
     * @param date Long类型的时间
     * @param specification 格式
     * @return java.lang.String
     * @Description TODO getDateFormat 传入Long类型时间和格式进行格式化
     * @author Administrator
     * @date 2018/4/13/013 19:29
     */
    public static String getDateFormat(Long date, String specification) {
        if (specification.equals("")) {
            return null;
        }
        String sTrim = specification.trim();
        SimpleDateFormat df = new SimpleDateFormat(sTrim);//设置日期格式
        String format;
        if (!date.equals("") && date != null) {
            format = df.format(date);//格式化日期
        } else {
            
            format = df.format(DAY);//格式化日期
        }
        return format;
    }

    /**
     * @param year 传入大于0的数字相应的就减少多少年
     * @param month 传入大于0的数字相应的就减少多少月
     * @return com.zd966.file.cloud.utils.DateModel
     * @Description TODO getTime 获取时间
     * @author Administrator
     * @date 2018/4/13/013 19:33
     */
    public static DateModel getTime(int year, int month) {
        Date date = new Date();
        String format = getDateFormat(date.getTime());
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (year > 0) {
            cal.add(Calendar.YEAR, -year);
        }
        if (month > 0) {
            cal.add(Calendar.MONTH, -month);
        }

        int harvest = cal.get(Calendar.YEAR);//获取年
        int monthInt = cal.get(Calendar.MONTH) + 1;//获取月，因为第一个月是0，所以要+1
        int first = cal.getActualMinimum(Calendar.DAY_OF_MONTH);//获取本月最小天数
        int last = cal.getActualMaximum(Calendar.DAY_OF_MONTH);//获取本月最大天数
        String monthString;
        if (monthInt < 10) {
            monthString = String.valueOf("0" + monthInt);
        } else {
            monthString = String.valueOf(monthInt);
        }
        String firstDayString;
        if (first < 10) {
            firstDayString = String.valueOf("0" + first);
        } else {
            firstDayString = String.valueOf(first);
        }
        String lastDayString;
        if (last < 10) {
            lastDayString = String.valueOf("0" + last);
        } else {
            lastDayString = String.valueOf(last);
        }

        StringBuffer beginDate = new StringBuffer();
        beginDate.append(harvest + "-" + monthString + "-" + firstDayString);

        StringBuffer endDate = new StringBuffer();
        endDate.append(harvest + "-" + monthString + "-" + lastDayString);

        DateModel dateModel = new DateModel();
        dateModel.setBeginDate(beginDate);
        dateModel.setEndDate(endDate);
        dateModel.setYear(harvest);
        dateModel.setMonth(monthInt);
        dateModel.setTime(format);
        return dateModel;
    }


    /**
     * 根据周数，获取开始日期、结束日期
     * @param week  周期  0本周，-1上周，-2上上周，1下周，2下下周
     * @return  返回date[0]开始日期、date[1]结束日期
     */
    public static Date[] getWeekStartAndEnd(int week) {
        DateTime dateTime = new DateTime();
        LocalDate date = new LocalDate(dateTime.plusWeeks(week));

        date = date.dayOfWeek().withMinimumValue();
        Date beginDate = date.toDate();
        Date endDate = date.plusDays(6).toDate();
        return new Date[]{beginDate, endDate};
    }

    /**
     * 对日期的【秒】进行加/减
     *
     * @param date 日期
     * @param seconds 秒数，负数为减
     * @return 加/减几秒后的日期
     */
    public static Date addDateSeconds(Date date, int seconds) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusSeconds(seconds).toDate();
    }

    /**
     * 对日期的【分钟】进行加/减
     *
     * @param date 日期
     * @param minutes 分钟数，负数为减
     * @return 加/减几分钟后的日期
     */
    public static Date addDateMinutes(Date date, int minutes) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusMinutes(minutes).toDate();
    }

    /**
     * 对日期的【小时】进行加/减
     *
     * @param date 日期
     * @param hours 小时数，负数为减
     * @return 加/减几小时后的日期
     */
    public static Date addDateHours(Date date, int hours) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusHours(hours).toDate();
    }

    /**
     * 对日期的【天】进行加/减
     *
     * @param date 日期
     * @param days 天数，负数为减
     * @return 加/减几天后的日期
     */
    public static Date addDateDays(Date date, int days) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusDays(days).toDate();
    }

    /**
     * 对日期的【周】进行加/减
     *
     * @param date 日期
     * @param weeks 周数，负数为减
     * @return 加/减几周后的日期
     */
    public static Date addDateWeeks(Date date, int weeks) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusWeeks(weeks).toDate();
    }

    /**
     * 对日期的【月】进行加/减
     *
     * @param date 日期
     * @param months 月数，负数为减
     * @return 加/减几月后的日期
     */
    public static Date addDateMonths(Date date, int months) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusMonths(months).toDate();
    }

    /**
     * 对日期的【年】进行加/减
     *
     * @param date 日期
     * @param years 年数，负数为减
     * @return 加/减几年后的日期
     */
    public static Date addDateYears(Date date, int years) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusYears(years).toDate();
    }
}

/**
 * @param
 * @author
 * @Description: TODO 时间实体类
 * @date 2018/4/13/013 17:48
 * @return
 */

 class DateModel {
    private StringBuffer beginDate;
    private StringBuffer endDate;
    private int year;
    private int month;
    private String time;

    public StringBuffer getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(StringBuffer beginDate) {
        this.beginDate = beginDate;
    }

    public StringBuffer getEndDate() {
        return endDate;
    }

    public void setEndDate(StringBuffer endDate) {
        this.endDate = endDate;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
 }
