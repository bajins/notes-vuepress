package com.zd966.file.cloud.handle;

/**
 * @author claer 自定义异常类
 * @program com.zd966.file.cloud.handle
 * @description UniversalException
 * @create 2018-04-24 20:41
 */
public class UniversalException extends RuntimeException{

    private Integer code;

    //通过ResultEnum枚举类获取message和code
    public UniversalException(ResultEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
