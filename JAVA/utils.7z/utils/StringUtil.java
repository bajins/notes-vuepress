package com.zd966.file.cloud.utils;

import java.util.Random;

/**
 * @program: com.zd966.file.cloud.utils
 * @description: StringUtil
 * @author:
 * @create: 2018-04-14 16:51
 */
public class StringUtil {


    /**
     * @param length需求生成多少位
     * @return java.lang.String
     * @Description TODO getStringRandom 生成随机数字和字母
     * @author Administrator
     * @date 2018/4/14/014 16:34
     */
    public static String getStringRandom(int length) {

        String val = "";
        Random random = new Random();
        //length为几位密码
        for (int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            //输出字母还是数字
            if ("char".equalsIgnoreCase(charOrNum)) {
                //输出是大写字母还是小写字母
                int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (random.nextInt(26) + temp);
            } else if ("num".equalsIgnoreCase(charOrNum)) {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
