package com.cyw.log.model;


public class SystemLogModel {

	private String description;
	private String method;
	private int type;
	private String ip;
	private String aberrantCode;
	private String aberrantDetail;
	private String params;
	private String createUser;
	private String createDate;
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
	public String getAberrantCode() {
		return aberrantCode;
	}
	public void setAberrantCode(String aberrantCode) {
		this.aberrantCode = aberrantCode;
	}
	public String getAberrantDetail() {
		return aberrantDetail;
	}
	public void setAberrantDetail(String aberrantDetail) {
		this.aberrantDetail = aberrantDetail;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	@Override
	public String toString() {
		return "SystemLogModel [description=" + description + ", method=" + method + ", type=" + type + ", ip=" + ip
				+ ", aberrantCode=" + aberrantCode + ", aberrantDetail=" + aberrantDetail + ", params=" + params
				+ ", createUser=" + createUser + ", createDate=" + createDate + "]";
	}

}
