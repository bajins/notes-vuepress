package com.cyw.log.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @program com.cyw.log.annotation
 * @description 自定义注解处理
 * @author claer zd966@zd966.com
 * @create 2018.5.4
 *
 */

@Target({ElementType.PARAMETER, ElementType.METHOD})//作用于参数或方法上  
@Retention(RetentionPolicy.RUNTIME)  
@Documented
public @interface EnableLog {

	/**
	 * 描述
	 * @return
	 */
	String description() default "描述";
	
	/**
     * 操作类型描述
     * @return
     */
    String operateTypeDesc() default "操作类型描述";

    /**
     * 操作类型
     * @return
     */
    long operateType() default -1;

    /**
     * 模块编码
     * @return
     */
    String moudleCode() default "模块编码";

    /**
     * 模块名称
     * @return
     */
    String moudleName() default "模块名称";

    /**
     * 业务类型
     * @return
     */
    String bussType() default "业务类型";
    /**
     * 业务类型描述
     * @return
     */
    String bussTypeDesc() default "业务类型描述";
}
