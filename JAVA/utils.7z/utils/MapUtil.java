package com.zd966.file.cloud.utils;

import java.util.HashMap;

/**
 * @author claer
 * @program com.zd966.file.cloud.utils
 * @description MapUtil
 * @create 2018-04-24 18:59
 */
public class MapUtil extends HashMap<String, Object> {

    @Override
    public MapUtil put(String key, Object value) {
        super.put(key, value);
        return this;
    }
}
