package com.zd966.file.cloud.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @program: com.zd966.file.cloud.utils
 * @description: FilePath
 * @author:
 * @create: 2018-04-12 09:54
 */
public class FilePath {


    /**
     * @Description TODO getAllFile 获取路径下的所有文件/文件夹 
     * @param directoryPath需要遍历的文件夹路径
	 * @param isAddDirectory是否将子文件夹的路径也添加到list集合中
     * @author Administrator
     * @date 2018/4/13/013 21:59
     * @return java.util.List<java.lang.String>
     */
    public static List<String> getAllFile(String directoryPath, boolean isAddDirectory) {
        List<String> list = new ArrayList<String>();
        File baseFile = new File(directoryPath);
        if (baseFile.isFile() || !baseFile.exists()) {
            return list;
        }
        File[] files = baseFile.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                if (isAddDirectory) {
                    list.add(file.getAbsolutePath());
                }
                list.addAll(getAllFile(file.getAbsolutePath(), isAddDirectory));
            } else {
                list.add(file.getAbsolutePath());
            }
        }
        return list;
    }

    /**
     * @param @param [file, resultFileName]
     * @return java.util.List<java.lang.String>
     * @Description: TODO getFilePathAll 获取文件夹下所有文件，包括子文件夹内的文件
     * @author
     * @date 2018/4/12/012 9:56
     */
    private List<String> getFilePathAll(File file, List<String> resultFileName) {
        File[] files = file.listFiles();
        if (files == null) return resultFileName;// 判断目录下是不是空的
        for (File f : files) {
            if (f.isDirectory()) {// 判断是否文件夹
                resultFileName.add(f.getPath());
                getFilePathAll(f, resultFileName);// 调用自身,查找子目录
            } else
                resultFileName.add(f.getPath());
        }
        return resultFileName;
    }

    /**
     *@param @param [filepath]
     *@Description: TODO readfile 读取某个文件夹下的所有文件
     *@author
     *@date 2018/4/12/012 10:02
     *@return boolean
     */
    public static boolean readfile(String filepath) {

        File file = new File(filepath);
        if (!file.isDirectory()) {
            System.out.println("文件");
            System.out.println("path=" + file.getPath());
            System.out.println("absolutepath=" + file.getAbsolutePath());
            System.out.println("name=" + file.getName());

        } else if (file.isDirectory()) {
            System.out.println("文件夹");
            String[] filelist = file.list();
            for (int i = 0; i < filelist.length; i++) {
                File readfile = new File(filepath + "\\" + filelist[i]);
                if (!readfile.isDirectory()) {
                    System.out.println("path=" + readfile.getPath());
                    System.out.println("absolutepath="
                            + readfile.getAbsolutePath());
                    System.out.println("name=" + readfile.getName());

                } else if (readfile.isDirectory()) {
                    readfile(filepath + "\\" + filelist[i]);
                }
            }

        }

        return true;
    }

    /**
     *@param @param [delpath]
     *@Description: TODO deleteFileAll 删除某个文件夹下的所有文件夹和文件
     *@author
     *@date 2018/4/12/012 10:02
     *@return boolean
     */
    public static boolean deleteFileAll(String delpath){

        File file = new File(delpath);
        if (!file.isDirectory()) {
            System.out.println("1");
            file.delete();
        } else if (file.isDirectory()) {
            System.out.println("2");
            String[] filelist = file.list();
            for (int i = 0; i < filelist.length; i++) {
                File delfile = new File(delpath + "\\" + filelist[i]);
                if (!delfile.isDirectory()) {
                    System.out.println("path=" + delfile.getPath());
                    System.out.println("absolutepath="
                            + delfile.getAbsolutePath());
                    System.out.println("name=" + delfile.getName());
                    delfile.delete();
                    System.out.println("删除文件成功");
                } else if (delfile.isDirectory()) {
                    deleteFileAll(delpath + "\\" + filelist[i]);
                }
            }
            file.delete();

        }

        return true;
    }
}
