package com.zd966.file.cloud.handle;

import com.zd966.file.cloud.utils.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author claer
 * @program com.zd966.file.cloud.handle
 * @description ExceptionHandle
 * @create 2018-04-24 20:07
 */
public class ExceptionHandle {


    /**
     * @param e
     * @return com.zd966.file.cloud.utils.Result
     * @Description TODO CatchException 捕获自定义异常
     * @author claer
     * @date 2018/4/24/024 20:35
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Result CatchException(Exception e) {
        //判断是否为自定义Exception
        if (e instanceof UniversalException) {
            UniversalException universalException = (UniversalException) e;
            return Result.error(universalException.getCode(), universalException.getMessage());
        } else {
            //自定义异常返回未知错误信息
            UniversalException universalException = new UniversalException(ResultEnum.UNKNOWN_ERROR);
            return Result.error(universalException.getCode(),universalException.getMessage());
        }
    }
}
