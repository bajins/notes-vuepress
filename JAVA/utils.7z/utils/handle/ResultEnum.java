package com.zd966.file.cloud.handle;

/**
 * @author claer 自定义返回异常message和code的枚举类
 * @program com.zd966.file.cloud.handle
 * @description ResultEnum
 * @create 2018-04-24 21:09
 */
public enum ResultEnum {
    /**
     * @param null
     * @return 
     * @Description TODO  自定义返回异常message和code
     * 构造方式：在下方输入:枚举name(code,message)
     * 使用方法：在需要捕获异常的地方输入throw new UniversalException(ResultEnum.自定义枚举name);
     * @author claer
     * @date 2018/4/24/024 21:26
     */
    UNKNOWN_ERROR(-1,"未知错误"),
    SUCCESS(0,"成功"),
    GET_VERIFY_ERROR(505,"获取验证码失败"),
    ;

    /** 返回状态码. */
    private Integer code;//枚举参数
    /** 返回状态信息. */
    private String message;//枚举参数

    ResultEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
