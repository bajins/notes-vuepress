package com.cyw.log.model;


public class SystemLogModel {

	private String description;
	private String method;
	private int type;
	private String ip;
	private String exceptionCode;
	private String exceptionDetail;
	private String params;
	private String createUser;
	private String createDate;
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getExceptionCode() {
		return exceptionCode;
	}
	public void setExceptionCode(String exceptionCode) {
		this.exceptionCode = exceptionCode;
	}
	public String getExceptionDetail() {
		return exceptionDetail;
	}
	public void setExceptionDetail(String exceptionDetail) {
		this.exceptionDetail = exceptionDetail;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	@Override
	public String toString() {
		return "SystemLog [description=" + description + ", method=" + method + ", type=" + type + ", ip=" + ip
				+ ", exceptionCode=" + exceptionCode + ", exceptionDetail=" + exceptionDetail + ", params=" + params
				+ ", createUser=" + createUser + ", createDate=" + createDate + "]";
	}
	
	
}
